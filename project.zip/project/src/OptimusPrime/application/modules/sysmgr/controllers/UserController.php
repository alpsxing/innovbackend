<?php

class Sysmgr_UserController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
        $this->_helper->layout->disableLayout();
    }

    public function indexAction()
    {
        // action body
    }


}


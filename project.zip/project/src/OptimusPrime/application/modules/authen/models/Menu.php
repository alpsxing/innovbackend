<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Menu
 *
 * @author apple
 */
class Authen_Model_Menu {
    //put your code here
    
    
   
}

?>
